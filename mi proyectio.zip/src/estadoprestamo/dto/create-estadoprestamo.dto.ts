export class CreateEstadoprestamoDto {
  estado : string;

}



